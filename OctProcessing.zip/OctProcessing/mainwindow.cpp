#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "OCTDLL.h"    


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QString name = ui->lineEdit->text();

    double Dice, Det;
    TSPRM(name.toStdString(), Dice, Det);


    ui->lineEdit_2->setText(QString::number(Dice, 'f', 3));
    ui->lineEdit_3->setText(QString::number(Det, 'f', 3));

    QPixmap pix(name+"_R.tif");

    // ������Ӧlabel�����ֱ�����
    ui->origImgLabel->setPixmap(pix.scaled(ui->origImgLabel->size(), Qt::KeepAspectRatio));




}
