#pragma once

#include <stdio.h>
#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>
#include <fstream>
using namespace cv;
using namespace std;

// ���嵼��/�����
#ifdef OCTDLL_EXPORTS
#define OCTDLL_API __declspec(dllexport)
#else
#define OCTDLL_API __declspec(dllimport)
#endif

 




extern "C" {  OCTDLL_API void TSPRM(const string name, double& Dice3, double& Det3); }
 





class OCTDLL
{
};

